

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.FileInputStream;
import java.io.FileOutputStream;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.util.coder.IDataXMLCoder;
// --- <<IS-END-IMPORTS>> ---

public final class emp

{
	// ---( internal utility methods )---

	final static emp _instance = new emp();

	static emp _newInstance() { return new emp(); }

	static emp _cast(Object o) { return (emp)o; }

	// ---( server methods )---




	public static final void utils (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(utils)>> ---
		// @sigtype java 3.5
		// [i] field:0:required type {"read","write"}
		// [i] record:1:required emps
		// [i] - field:0:required name
		// [i] - record:0:required address
		// [i] -- field:0:required houseno
		// [i] -- field:0:required location
		// [i] -- field:0:required city
		// [i] -- field:0:required phone
		// [i] -- field:0:required landmark
		// [i] -- field:0:required pincode
		// [o] record:1:required emps
		// [o] - field:0:required name
		// [o] - record:0:required address
		// [o] -- field:0:required houseno
		// [o] -- field:0:required location
		// [o] -- field:0:required city
		// [o] -- field:0:required phone
		// [o] -- field:0:required landmark
		// [o] -- field:0:required pincode
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	type = IDataUtil.getString( pipelineCursor, "type" );
		
		if(type.equals("read")){
			IDataXMLCoder coder = new IDataXMLCoder();
			try {
				IData decode = coder.decode(new FileInputStream("/home/test/emp_data.xml"));
				IDataCursor  cursor = decode.getCursor();
				IData[]	emps = IDataUtil.getIDataArray( cursor, "emps" );
				IDataUtil.put( pipelineCursor, "emps", emps );
				cursor.destroy();
			} catch (Exception e) {
			}
			pipelineCursor.destroy();
		}else{
			IDataXMLCoder coder = new IDataXMLCoder();
			try {
				coder.encode(new FileOutputStream("/home/test/emp_data.xml"),pipeline);
			} catch (Exception e) {
			}
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

